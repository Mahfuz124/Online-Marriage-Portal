<!DOCTYPE html>
<html>
<head>
	<title>Online Marriage Portal</title>
	<link rel="stylesheet" href="gallery.css">
</head>
<body>
	<h1>Gallery of New Life</h1>
	<div class="gallery">
		<div class="image">
		<a href="image/img-1.jpg" target="_blank"><img src="image/img-1.jpg" width="300" height="200"></a>
		<button type="submit" class="download-btn">Saad & Maria's Wedding</button>
	</div>
   </div>

   <div class="gallery">
		<div class="image">
		<a href="image/img-2.jpg" target="_blank"><img src="image/img-2.jpg" width="300" height="200"></a>
		<button type="submit" class="download-btn">Riya & Rahman's Wedding</button>
	</div>
   </div>

   <div class="gallery">
		<div class="image">
		<a href="image/img-3.jpg" target="_blank"><img src="image/img-3.jpg" width="300" height="200"></a>
		<button type="submit" class="download-btn">Asif & Maha's Wedding</button>
	</div>
   </div>

   <div class="gallery">
		<div class="image">
		<a href="image/img-4.jpg" target="_blank"><img src="image/img-4.jpg" width="300" height="200"></a>
		<button type="submit" class="download-btn">Sadi & Pushpa's Wedding</button>
	</div>
   </div>

   <div class="gallery">
		<div class="image">
		<a href="image/img-5.jpg" target="_blank"><img src="image/img-5.jpg" width="300" height="200"></a>
		<button type="submit" class="download-btn">Anika & Arif's Wedding</button>
	</div>
   </div>

<div class="gallery">
		<div class="image">
		<a href="image/img-6.jpg" target="_blank"><img src="image/img-6.jpg" width="300" height="200"></a>
		<button type="submit" class="download-btn">Mahir & Meem's Wedding</button>
	</div>
   </div>

   <div class="gallery">
		<div class="image">
		<a href="image/img-7.jpg" target="_blank"><img src="image/img-7.jpg" width="300" height="200"></a>
		<button type="submit" class="download-btn">Shanto & Sara's Wedding</button>
	</div>
   </div>

   <div class="gallery">
		<div class="image">
		<a href="image/img-8.jpg" target="_blank"><img src="image/img-8.jpg" width="300" height="200"></a>
		<button type="submit" class="download-btn">Shawon & Ritu's Wedding</button>
	</div>
   </div>

<div class="gallery">
		<div class="image">
		<a href="image/img-9.jpg" target="_blank"><img src="image/img-9.jpg" width="300" height="200"></a>
		<button type="submit" class="download-btn">Sami & Nila's Wedding</button>
	</div>
   </div>


<div class="gallery">
		<div class="image">
		<a href="image/img-10.jpeg" target="_blank"><img src="image/img-10.jpeg" width="300" height="200"></a>
		<button type="submit" class="download-btn">Zara & Nafis's Wedding</button>
	</div>
   </div>



</body>
</html>