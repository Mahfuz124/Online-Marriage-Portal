<!DOCTYPE html>
<html>
<head>
	<title>Online Marriage Portal</title>
	<link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>
	<div class="logsign">
		<div class="form-box">
			<div class="button-box">
				<div id="btn"></div>
				<button type="button" class="toggle-btn" onclick="login()">Log In</button>
				<button type="button" class="toggle-btn" onclick="register()">Sign Up</button>
				
			</div>
			<form id="login" class="input-group" action="login_c.php" method="post">
				<input type="text" name="user" class="input-field" placeholder="User Id" required>
				<input type="text" name="Password" class="input-field" placeholder="Enter Password" required>
				<input type="checkbox" class="chech-box"><span>Remember Password</span>
				<button type="submit" class="submit-btn">Log In</button>
			</form>
			<form id="register" class="input-group" action="signin_c.php" method="post">
				<input type="text"  name="fname" class="input-field" placeholder="Fast Name" required>
				<input type="text"  name="lname" class="input-field" placeholder="Last Name" required>
				<input type="text" name="uname" class="input-field" placeholder="User Id" required>
				<input type="email" name="email" class="input-field" placeholder="Email Id" required>
				<input type="text" name="password" class="input-field" placeholder="Enter Password" required>

				<input type="checkbox" class="chech-box"><span>I agree to the terms & conditions</span>
				<button type="submit" class="submit-btn">Sign Up</button>
			</form>
			
		</div>
</div>
<script>
	var x=document.getElementById("login");
	var y=document.getElementById("register");
	var z=document.getElementById("btn");

	function register(){
		x.style.left="-400px";
		y.style.left="50px";
		z.style.left="100px";
	}
	function login(){
		x.style.left="50px";
		y.style.left="450px";
		z.style.left="0px";
	}
</script>

</body>
</html>