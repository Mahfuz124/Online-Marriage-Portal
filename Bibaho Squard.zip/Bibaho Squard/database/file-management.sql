-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2020 at 06:04 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `file-management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins_profile`
--

CREATE TABLE IF NOT EXISTS `admins_profile` (
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins_profile`
--

INSERT INTO `admins_profile` (`fname`, `lname`, `uname`, `email`, `password`) VALUES
('mahfuz', 'hussain', 'mahfuz12', 'mahfuzhussain@gmail.com', 'mahfuz1245'),
('sakib', 'ahmed', 'sakib12', 'sakib@gmail.com', 'sakib1245');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`name`, `email`, `message`) VALUES
('mahfuz', 'm@gmail.com', 'hi,how are you');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE IF NOT EXISTS `files` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `pdf` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `name`, `image`, `pdf`) VALUES
(4, 'Mahfuz Hussain Shimul', 'uploads/-506710589mahfuz.jpg', 'uploads/-506710589mahfuz_biodata.pdf'),
(5, 'Sakib Ahmed', 'uploads/-372391063sakib.jpg', 'uploads/-372391063sakib_biodata.pdf'),
(6, 'Anamika Paul', 'uploads/-525956173suhana.jpg', 'uploads/-525956173anamika_biodata.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `uname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`fname`, `lname`, `uname`, `email`, `password`) VALUES
('amir', 'khan', 'amir12', 'amir@gmail.com', 'amir1245'),
('lima', 'begum', 'lima1245', 'lima@gmail.com', 'lima1245'),
('mahfuz', 'hussain', 'mahfuz1245', 'mahfuz@gmail.com', 'mahfuz1245');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins_profile`
--
ALTER TABLE `admins_profile`
 ADD PRIMARY KEY (`uname`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
 ADD PRIMARY KEY (`email`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
 ADD PRIMARY KEY (`uname`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
