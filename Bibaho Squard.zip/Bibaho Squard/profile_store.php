<?php

$random =rand(999, 999999999999);
$image = 'uploads/'.$random. $_FILES['image']['name'];


move_uploaded_file($_FILES['image']['tmp_name'], $image);



$pdf = 'uploads/'.$random. $_FILES['pdf']['name'];


move_uploaded_file($_FILES['pdf']['tmp_name'], $pdf);

$name = $_POST['name'];

$conn = mysqli_connect('localhost:3307', 'root', '', 'file-management');
     $sql = "INSERT INTO files VALUES(NULL,'$name','$image', '$pdf')";
       mysqli_query($conn,$sql);
       header("Location: admin_panel.php");
?>