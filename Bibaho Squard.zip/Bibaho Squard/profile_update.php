<?php

    $id = $_GET['id'];
    $name = $_POST['name'];
    

    $conn = mysqli_connect('localhost:3307', 'root', '', 'file-management');
    
    
    $sql = "SELECT * FROM files WHERE id = '$id' ";
    $result = mysqli_query($conn,$sql);
    
    $data = mysqli_fetch_assoc($result);

    $pdf1 = '';
    $update_sql = "UPDATE files SET name = '$name'";

if(!empty($_FILES['pdf']['name'])) {
    $random =rand(999, 999999999999);

    $pdf = 'uploads/'.$random. $_FILES['pdf']['name'];
     move_uploaded_file($_FILES['pdf']['tmp_name'], $pdf);

    $update_sql .= ",pdf = '$pdf'";
    if(!empty($data['pdf'])) {
        unlink($data['pdf']);
    }
}

if(!empty($_FILES['image']['name'])) {
    $random =rand(999, 999999999999);

    $pdf = 'uploads/'.$random. $_FILES['image']['name'];
     move_uploaded_file($_FILES['image']['tmp_name'], $image);

    $update_sql .= ",image = '$image'";
    if(!empty($data['image'])) {
        unlink($data['image']);
    }
}

  
  
  $update_sql .= "WHERE id = '$id' ";
  if(mysqli_query($conn,$update_sql)){
      header("Location:admin_panel.php");
  }