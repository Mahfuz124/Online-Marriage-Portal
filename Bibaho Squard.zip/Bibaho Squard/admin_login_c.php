<?php
session_start();
$con=mysqli_connect('localhost:3307','root','');
mysqli_select_db($con,'file-management');

$user=$_POST['user'];
$password=$_POST['Password'];

$s="select * from admins_profile where uname='$user' && Password='$password'";
$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);

if($num==1){
	$n=mysqli_query($con,"select * from admins_profile where uname='$user' && Password='$password'");
	$row=mysqli_fetch_assoc($n);
	$nnn=$row['fname'];
	$_SESSION['name']=$nnn;
	header('location:admin_panel.php');
}
else{
	echo "You are Not Register";
	header('location:admin_index.php');
}
?>