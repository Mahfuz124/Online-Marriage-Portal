<?php

$id = $_GET['id'];

$conn = mysqli_connect('localhost:3307', 'root', '', 'file-management');


$sql = "SELECT * FROM files WHERE id = '$id' ";
$result = mysqli_query($conn,$sql);

$data = mysqli_fetch_assoc($result);


if(file_exists($data['pdf'])) {
    unlink($data['pdf']);
}

if(file_exists($data['image'])) {
    unlink($data['image']);
}



$sql = "DELETE FROM files WHERE id = '$id' ";
       
mysqli_query($conn,$sql);

       header("Location: admin_panel.php");
?>