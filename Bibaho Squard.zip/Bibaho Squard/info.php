<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Online Marriage Portal</title>
	<link rel="stylesheet" type="text/css" href="info.css">
	<meta name="viewport" content="width=device-width,initial-sclae=1.0">
</head>
<body>
	<div class="about-section">
		<div class="inner-width">
			<h1>About Us</h1>
			<div class="border"></div>
			<div class="about-section-row">
			<div class="about-section-col">
			<div class="about">
				<p>
				The Online Marriage Portal website is a online based matchmaker.Where people can easily get their equal.Thereby it is more helpful for any kind of people.Simple to use and exclusively online Premium matrimony services make us a differentiator amongst other matrimonial sites.We believe in providing a secure, easy to use and convenient matrimonial matchmaking experience to all of our members.Upload your profile for free to find your life partner.
				</p>
				
			</div>
			</div>
		<br>
		<div class="about-section-col">
			<div class="a-ratings">
				<div class="p-ratings">
					<div class="title">Peoples Rating</div>
					<div class="progress">
						<div class="progress-bar p1"> <span>70%</span></div>
					</div>
				</div>

				<div class="p-ratings">
					<div class="title">Event Packages Rating</div>
					<div class="progress">
						<div class="progress-bar p2"> <span>80%</span></div>
					</div>
				</div>

				<div class="p-ratings">
					<div class="title">Our Services Rating</div>
					<div class="progress">
						<div class="progress-bar p3"> <span>90%</span></div>
					</div>
				</div>
			</div>

			</div>
			</div>
		</div>

	</div>

</body>
</html>