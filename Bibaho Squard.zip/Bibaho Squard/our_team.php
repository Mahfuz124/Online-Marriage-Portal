<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Online Marriage Portal</title>
	<link rel="stylesheet" type="text/css" href="our_team.css">
	<meta name="viewport" content="width=device-width,initial-sclae=1.0">
</head>
<body>
	<div class="team">
		<h1 class="heading"><span>meet</span>Our Team</h1>
		<div class="profiles">
			<div class="profile">
				<img src="image/mahfuz.jpg" class="profile-img">
				<h3 class="user-name">Mahfuz Hussain Shimul</h3>
				<h5>Creative Director</h5>
				<p>I am a web developer.I want to do something for people.I hope our website helps you.I cordially want to say that we are always ready to serve you.Stay with us and make us inspired</p>
			</div>
		</div>

		<div class="profiles">
			<div class="profile">
				<img src="image/sakib.jpg" class="profile-img">
				<h3 class="user-name">Sakib Ahmed</h3>
				<h5>Creative Marketing Officer</h5>
				<p>I am a web developer.I want to do something for people.I hope our website helps you.I cordially want to say that we are always ready to serve you.Stay with us and make us inspired</p>
			</div>
		</div>
	</div>

</body>
</html>