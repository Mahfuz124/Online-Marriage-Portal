<?php
    $conn = mysqli_connect('localhost:3307','root','','file-management');
    $sql = "SELECT * from files";
     $result = mysqli_query($conn, $sql);


?>

<!DOCTYPE html>
<html>
<head>
	<title>Online Marriage Portal</title>
	<link rel="stylesheet" href="f_profile.css">
</head>
<body>
		<h1>Finds Your Life Partner</h1>
		<?php while($row = mysqli_fetch_assoc($result)) { ?>
	<div class="gallery">
	
		<div class="image">
		<img src="<?php echo $row['image'];?>" width="200" height="150">
		<div id="name">
			<a href="<?php echo $row['pdf'];?>"><?php echo $row['name']?></a>
		</div>
		
	</div>
	
   </div>
   <?php } ?>

</body>
</html>