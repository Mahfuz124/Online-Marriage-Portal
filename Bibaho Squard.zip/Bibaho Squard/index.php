<!DOCTYPE html>
<html>
<head>
	<title>Online Marriage Portal</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
		<div class="main">
			<div class="logo">
				<img src="image/logo.png">
			</div>
			<ul>
				<li class="active"><a href="index.php">Home</a></li>
				<li><a href="event.php">Event Packages</a></li>
				<li><a href="bio.php">Drop a CV</a></li>
				<li><a href="gallery.php">Gallery</a></li>
				<li><a href="info.php">About Us</a></li>
				<li><a href="contact.php">Contact Us</a></li>
				<li><a href="login.php">Login</a></li>
			</ul>
		</div>
		<div class="title">
			<h1>Finds Your Equal</h1>
			
		</div>
		<div class="button">
			<a href="f_profile.php" class="btn">Finds A Profile</a>
		</div>

	</header>
	<footer>
		<div id="footer">
			<p>All Copyrights Reserved #2020 &copy;Online Marriage Portal</p>
		</div>
	</footer>
	


</body>
</html>