<!DOCTYPE html>
<html>
<head>
	<title>Online Marriage Portal</title>
	<link rel="stylesheet" type="text/css" href="contact.css"></link>
	
</head>
<body>
	<div class="contact-title">
		<h1>Contact With Us</h1>
		<h2>*for any query please fill the form*</h2>
	</div>
	<div class="contact-form">
		<form id="contact-form" method="post" action="contact-c.php">
			<input type="text" name="name" class="form-control" placeholder="Your Name" required>
			<br>
			<input type="email" name="email" class="form-control" placeholder="Your Email" required>
			<br>
			<textarea name="message" class="form-control" placeholder="Message" row="4" required></textarea>
			<br>
			<input type="submit" class="form-control submit" value="SUBMIT">



		</form>
	</div>
	
</body>
</html>