<?php
    $conn = mysqli_connect('localhost:3307','root','','file-management');
    $sql = "SELECT * from files";
     $result = mysqli_query($conn, $sql);


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
        integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
        <link rel="stylesheet" href="admin_panel.css">
    <title>Online Marriage Portal</title>
</head>

<body>
<nav class="navbar navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="#">Admin Dashboard</a>
    <div>
      <ul class="navbar-nav mr-auto">
            <li class="nav-item">
            <a href="admin_logout.php" class="btn  text-white">Logout</a>
            </li>
       </ul>
    </div>
    </div>
  </nav>

  <section class="profile">
  <div class="container py-5 ">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                       <h1 class="text-center">Add a Profile</h1>
                    </div>
                    <div class="card-body">
					<a href="add_profile.php" class="btn btn-primary add mb-5 mt-3">Add a Profile</a>
                           
                            <?php while($row = mysqli_fetch_assoc($result)) { ?>
                                
                                    
                                     <div class="row">
                                         <div class="col-lg-9">
                                            <h3><?php echo $row['name']; ?> </h3>
                                            <img src="<?php echo $row['image']; ?>" alt="">
                                         </div>
                                         <hr>
                                         <div class="col-lg-3">
                                         
                                         <a href="<?php echo $row['pdf']; ?>"  class="btn btn-secondary">View</a>
                                    
                                    <a href="profile_edit.php?id=<?php echo $row['id'] ?>" class="btn btn-success" > Edit </a>
                                        <a href="profile_delete.php?id=<?php echo $row['id'] ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')"> Delete </a>
                                         </div>
                                     </div>
                                     <hr>
                                 <hr>
                                         <br>
                            <?php } ?>
                            
                       
                        
                    </div>
                </div>
            </div>
           
        </div>
    </div>

  </section>

  <footer class="text-center bg-dark py-3">
      <p class="text-white">All Copyrights Reserved #2020 &copy;Online Marriage Portal</p>
  </footer>
    


    <!-- JS, Popper.js, and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"
        integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"
        integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous">
    </script>
</body>
</html>