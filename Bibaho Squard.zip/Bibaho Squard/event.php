<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Online Marriage Portal</title>
	<link rel="stylesheet" href="event.css">
</head>
<body>
	<div class="wrapper">
		<div class="single-price">
			<h1>Basic</h1>
			<div class="price">
				<h2>$1000</h2>
			</div>
			<div class="deals">
				<h4>1.Basic Gaye Holud Place</h4>
				<h4>2.Gaye Holud Place Decoration</h4>
				<h4>3.Gaye Holud Photoshot</h4>
				<h4>4.Basic Wedding Place</h4>
				<h4>5.Wedding Place Decoration</h4>
				<h4>6.Wedding Photoshot</h4>
				<h4>7.Basic Walima Place</h4>
				<h4>8.Walima Place Decoration</h4>
				<h4>9.Walima Photoshot</h4>
			</div>
			<a href="select.php">Select</a>
		</div>
		<div class="single-price">
			<h1>Standard</h1>
			<div class="price">
				<h2>$2000</h2>
			</div>
			<div class="deals">
				<h4>1.Standard Gaye Holud Place</h4>
				<h4>2.Gaye Holud Place Decoration</h4>
				<h4>3.Gaye Holud Photoshot</h4>
				<h4>4.Standard Wedding Place</h4>
				<h4>5.Wedding Place Decoration</h4>
				<h4>6.Wedding Photoshot</h4>
				<h4>7.Standard Walima Place</h4>
				<h4>8.Walima Place Decoration</h4>
				<h4>9.Walima Photoshot</h4>
			</div>
			<a href="select.php">Select</a>
		</div>
		<div class="single-price">
			<h1>Premium</h1>
			<div class="price">
				<h2>$4000</h2>
			</div>
			<div class="deals">
				<h4>1.Premium Gaye Holud Place</h4>
				<h4>2.Gaye Holud Place Decoration</h4>
				<h4>3.Gaye Holud Photoshot</h4>
				<h4>4.Premium Wedding Place</h4>
				<h4>5.Wedding Place Decoration</h4>
				<h4>6.Wedding Photoshot</h4>
				<h4>7.Premium Walima Place</h4>
				<h4>8.Walima Place Decoration</h4>
				<h4>9.Walima Photoshot</h4>
			</div>
			<a href="select.php">Select</a>
		</div>
	</div>

</body>
</html>